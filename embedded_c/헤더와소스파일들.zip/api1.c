#include "api1.h"
#include "common.h"

void abc() {
	x = 200;
}