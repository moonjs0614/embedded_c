#include "common.h"
int x;

void common_func() {

}