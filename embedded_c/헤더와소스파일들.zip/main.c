#include <stdio.h>
#include "common.h"
#include "api1.h"
#include "api2.h"

int main()
{
	x = 100;
	abc();
	printf("%d\n", x);
	return 0;
}