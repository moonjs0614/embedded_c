#include <stdio.h>
#include <string.h>
#include <string.h>
#include <stdlib.h>

//void *fullwrite();
//void *fullread();
#define MAX_LEN 100

void fullwrite(){
	FILE *fp;
	fp = fopen("nand.txt", "w");
	
	for(int i = 0; i < MAX_LEN; i++){
		fprintf(fp, "0xFFFFFFFF\n");
	}

	fclose(fp);
}

void fullread(){
	FILE *fp;
	fp = fopen("nand.txt", "r");

	char str[50];
	int line_cnt = 0;

	while(fgets(str, 50, fp) != NULL) {
		printf("%d line : %s", line_cnt++ ,str);

		// file save to result.txt
		//FILE *save_result = fopen("result.txt", "w");
		//fprintf(save_result, str);
		//fclose(save_result);
	}
	fclose(fp);
}

void read(int line) {
	FILE *fp;
	fp = fopen("nand.txt", "r");

	char str[50];
	int line_cnt = 0;

	while(fgets(str, 50, fp) != NULL) {
		line_cnt++;
		if(line_cnt == line){
			FILE *save_result = fopen("result.txt", "w");

			fprintf(save_result, "%s\n", str);
			fclose(save_result);
		}
	}
	fclose(fp);
}

void write(int line, char *address){
	system("touch tmp.txt");
	FILE *fp = fopen("nand.txt", "r");
	FILE *tmp = fopen("tmp.txt", "a");

	char str[50];
	int line_cnt = 0;

	while(fgets(str, 50, fp) != NULL) {
		line_cnt++;
		if(line_cnt == line){
			fprintf(tmp, "%s\n", address);
		}
		else {
			fprintf(tmp, "%s", str);
		}
	}

	fclose(fp);
	fclose(tmp);

	system("rm nand.txt");
	system("mv tmp.txt nand.txt");
}

int main(int argc, char* argv[]){
	if(strcmp(argv[1], "fullwrite") == 0){
		printf("fullwrite\n");
		fullwrite();
	}
	else if(strcmp(argv[1], "fullread") == 0){
		printf("fullread\n");
		fullread();
	}
	else if(strcmp(argv[1], "ssd") == 0 && strcmp(argv[2], "R") == 0){
		printf("read\n");
		int ln = atoi(argv[3]);
		read(ln);
	}
	else if(strcmp(argv[1], "ssd") == 0 && strcmp(argv[2], "W") == 0){
		printf("write\n");
		int ln = atoi(argv[3]);
		write(ln, argv[4]);
	}

	return 0;
}
