#pragma warning(disable:4996)
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int validCheck_valueCheck(char* val) { // 정상이면 1, 오류면 0 반환
    if (!((strlen(val) == 11) && (val[10] == '\n'))) {
        return 0;
    }
    if (val[0] != '0') {
        return 0;
    }
    if (val[1] != 'x') {
        return 0;
    }
    for (int i = 2; i < 10; i++) {
        if (!((val[i] >= '0' && val[i] <= '9') || (val[i] >= 'A' && val[i] <= 'F'))) {
            return 0;
        }
    }
    return 1;
}

int validCheck(char* inputs[]) { // 정상이면 1, 에러면 0 반환
    char* ptrs[10]; // 포인터 배열
    ptrs[0] = strtok(inputs, " ");

    int i = 0;
    while (ptrs[i] != NULL) {
        ptrs[i + 1] = strtok(NULL, " ");
        i++;
    }
    if (strcmp(ptrs[0], "R") == 0 && i != 2) { // 추가코드: R일 때 인자 갯수 판별
        return 0;
    }
    if (!((strcmp(ptrs[0], "W") == 0) || (strcmp(ptrs[0], "R") == 0))) { // 0-2-2
        return 0;
    }
    if (!((atoi(ptrs[1]) >= 0) && (atoi(ptrs[1]) < 100))) { // 0-2-3
        return 0;
    }
    if (atoi(ptrs[1]) == 0 && strcmp(ptrs[1], "0") != 0) { // atoi함수는 잘못된 문자를 입력받았을 때 0을 리턴하기 때문에, atoi() 결과가 0일때 실제 0을 입력 받았는지 아닌지를 판별하는 조건문
        return 0;
    }
    if (strcmp(ptrs[0], "W") == 0) { // 0-2-4
        if ((strcmp(ptrs[0], "W") == 0) && i != 3) { // 추가코드 : W일때 인자 갯수 판별
            return 0;
        }

        if (!(validCheck_valueCheck(ptrs[2]))) { // validCheck_valueCheck() : 0x???????? 형식을 만족하는지 판별하는 함수
            return 0;
        }
    }
    return 1; // 받은 인자가 더 많은 경우는 고려하지 않는다.
}

int main(int argc, char* argv[]) {
    while (1) {
        printf("Shell >> ");

        char input[10];
        scanf("%s", input);


        if (strcmp(input, "exit") == 0) {
            return 0;
        }
        else if (strcmp(input, "fullwrite") == 0) {
            system("./ssd fullwrite");
        }
        else if (strcmp(input, "fullread") == 0) {
            system("./ssd fullread");
        }
        else if (strcmp(input, "help") == 0) {
            printf("write 사용법 : write 줄번호 주소 \n");
            printf("read 사용법 : read 줄번호 \n");
            printf("fullwrite 사용법 : fullwrite  \n");
            printf("fullread 사용법 : fullread  \n");
            printf("줄 번호 : 0~99, 주소 : hex로 4byte\n");
        }
        else if (strcmp(input, "testapp1") == 0) {
            printf("testapp1");

            system("./ssd fullwrite");
            system("./ssd fullread");
        }
        else if (strcmp(input, "ssd") == 0) {
            char inputs[100];
            fgets(inputs, sizeof(inputs), stdin);

			char command[50];
			sprintf(command, "./ssd ssd%s", inputs);
            if (!(validCheck(inputs))) {
                printf("INVALID COMMAND\n");
            }
			else{
				//printf("%s\n", command);
				system(command); // ./ssd ssd W 10 0x12345678
			}
        }
    }

    return 0;
}


