#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int validCheck_valueCheck(char* val) { // 정상이면 1, 오류면 0 반환
    if (strlen(val) != 10) {
        return 0;
    }
    if (val[0] != '0') {
        return 0;
    }
    if (val[1] != 'x') {
        return 0;
    }
    for (int i = 2; i < 10; i++) {
        if (!((val[i] >= '0' && val[i] <= '9') || (val[i] >= 'A' && val[i] <= 'F'))) {
            return 0;
        }
    }
    return 1;
}

int validCheck(char* argv[]) { // 정상이면 1, 에러면 0 반환
    if (strcmp(argv[1], "ssd") == 0) { // 0-2-1
        return 0;
    }
    if (!(strcmp(argv[2], "W") == 0 || strcmp(argv[2], "R") == 0)) { // 0-2-2
        return 0;
    }
    if (! ((atoi(argv[3]) >= 0) && (atoi(argv[3]) < 100)) ) { // 0-2-3
        return 0;
    }
    if (atoi(argv[3]) == 0 && strcmp(argv[3], "0") != 0) { // atoi함수는 잘못된 문자를 입력받았을 때 0을 리턴하기 때문에, atoi() 결과가 0일때 실제 0을 입력 받았는지 아닌지를 판별하는 조건문
        return 0;
    }
    if (strcmp(argv[2], "W") == 0) { // 0-2-4
        if (!(validCheck_valueCheck(argv[4]))) { // validCheck_valueCheck() : 0x???????? 형식을 만족하는지 판별하는 함수
            return 0;
        }
    }

    return 1; // 받은 인자가 더 많은 경우는 고려하지 않는다.
}

int main(int argc, char* argv[]) { 

     // argv[1] = "ssd";
     // argv[2] = "R";
     // argv[3] = "10";

    for (int i = 0; i < 4; i++) {
        printf("%s\n", argv[i]);
    }
    
    // 0. 인자 오류 여부 검출
    if (!(validCheck(argv))) { 
        printf("INVALID COMMAND");
        return 0;
    }
    else {
        printf("PASSED"); // debug
    }

    return 0;
}

/*
pseudo.txt

0. 프로그램 실행으로부터 argv[] 를 받는다.
    0-1. 받는 명령어는 4개 [ssd, W|R, NUM, value], 인덱스는 1부터 5까지
        0-1-1. W면 value가 있고, read 면 value가 없다.
    0-2. 받은 명령어에 오류가 있는지 없는지 확인한다.
        0-2-1. 1번이 ssd인지
        0-2-2. 2번이 W 혹은 R인지
        0-2-3. 3번이 0~99의 정수인지
        0-2-4. 2번이 W라면 
            0-2-5. 4번의 인덱스0 이 0인지, 인덱스1이 x인지, 그 뒤의 8자리가 0~9 || A~F 인지
    0-3. 0-2의 과정중 하나라도 오류가 있으면 "INVALID COMMAND" 를 출력한다.

1. 같은 위치 내에 nand.txt 와 result.txt가 있는지 없는지 확인한다.
    1-1. 있으면 pass하고, 없으면 두 파일을 만든다.
    1-2. nand.txt를 만들 때 100줄 모두 0x00000000 을 넣는다.
2. 만약 명령어가 W라면
    2-1. nand.txt 의 NUM번에 value를 쓴다.
3. 만약 명령어가 R이라면
    3-1. nand.txt 의 NUM번 줄을 result.txt에 덮어쓴다.


예시:

1. input 이 ssd W 3 0x1298CDEF 일 경우 3번 LBA 영역에 0x1298CDEF 값을 저장한다.
잘 못 넣을 경우 INVALID COMMAND 을 출력한다.
2. input 이 ssd R 2 일 경우 2번 영역 LBA의 값을 출력한다.
잘 못 넣을 경우 INVALID COMMAND 을 출력한다.

*/
