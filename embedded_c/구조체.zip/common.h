#pragma once

typedef struct _COMMON_T_ {
	int a;
	int b;
};