#ifndef __API1_H__
#define __API1_H__

void abc(T t); 

#endif