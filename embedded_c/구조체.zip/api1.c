#include "api1.h"

typedef struct _T_ {
	int x;
	int y;
} T;

void abc(T t) {
	T t = { 1, 2 };
}